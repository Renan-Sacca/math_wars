from django.shortcuts import render,redirect

from django.contrib import messages

def dashboard(request):
    return render(request,'dashboard.html')